//package Items;
//
//public class Bag extends Item {
//
//
//    public Bag(String name, String description, double weight) {
//        super(name, description, weight);
//    }
//}
